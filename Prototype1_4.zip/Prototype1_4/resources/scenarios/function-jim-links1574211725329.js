(function(window, undefined) {

  var jimLinks = {
    "f80f0a45-77df-4324-8c41-30b7e2f471b1" : {
      "Text_16" : [
        "45fe9b48-b49f-4fc6-833a-91d3a6bb3f56"
      ],
      "Rectangle_5" : [
        "45fe9b48-b49f-4fc6-833a-91d3a6bb3f56"
      ],
      "Text_17" : [
        "0b1512e3-2f35-4c77-9c09-952f6458f352"
      ],
      "Rectangle_6" : [
        "0b1512e3-2f35-4c77-9c09-952f6458f352"
      ],
      "Text_21" : [
        "84d5e668-0f84-4a22-b975-0e5f243c1213"
      ],
      "Rectangle_8" : [
        "84d5e668-0f84-4a22-b975-0e5f243c1213"
      ],
      "Image_149" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_101" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1",
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_7" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_18" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_22" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ]
    },
    "1feafde6-a728-434d-b077-538c7c943721" : {
      "Text_377" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_1" : [
        "5ea20b8c-485b-4754-9b54-2ac90bf47820"
      ],
      "Rectangle_4" : [
        "59a40226-fef3-4102-b072-c84d1387ab00"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_11" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_12" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_374" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_375" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_376" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_18" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_5" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_16" : [
        "45fe9b48-b49f-4fc6-833a-91d3a6bb3f56"
      ],
      "Text_36" : [
        "0b1512e3-2f35-4c77-9c09-952f6458f352"
      ],
      "Text_37" : [
        "84d5e668-0f84-4a22-b975-0e5f243c1213"
      ],
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_149" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_101" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1",
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_7" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_25" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_26" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ]
    },
    "0b1512e3-2f35-4c77-9c09-952f6458f352" : {
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_149" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_101" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1",
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_7" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_18" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_22" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ]
    },
    "45fe9b48-b49f-4fc6-833a-91d3a6bb3f56" : {
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_149" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_101" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1",
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_7" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_18" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_22" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ]
    },
    "5ea20b8c-485b-4754-9b54-2ac90bf47820" : {
      "Text_Dashboad_1" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_377" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_14" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_16" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_374" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_375" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_376" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ]
    },
    "a179181f-3783-4f8e-bc39-745e9d8c4b39" : {
      "Text_16" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_10" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_12" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_25" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_26" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_112" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ]
    },
    "fa35afbc-3c59-4e9f-b320-94fc011e6274" : {
      "Text_Dashboad_1" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Rectangle_1" : [
        "ff979c70-2dda-4728-9936-437816063a73"
      ],
      "Rectangle_6" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_18" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_10" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_12" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_25" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_26" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_112" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ]
    },
    "59a40226-fef3-4102-b072-c84d1387ab00" : {
      "Text_Dashboad_1" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_377" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_11" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_12" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_374" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_375" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_376" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ]
    },
    "9a828618-233d-48ee-9f0c-3f3fbfbfabc9" : {
      "Text_Dashboad_1" : [
        "0b1512e3-2f35-4c77-9c09-952f6458f352"
      ],
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_149" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_101" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1",
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_7" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_18" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_22" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ]
    },
    "84d5e668-0f84-4a22-b975-0e5f243c1213" : {
      "Text_cell_18" : [
        "9a828618-233d-48ee-9f0c-3f3fbfbfabc9"
      ],
      "Text_cell_30" : [
        "9a828618-233d-48ee-9f0c-3f3fbfbfabc9"
      ],
      "Text_cell_19" : [
        "9a828618-233d-48ee-9f0c-3f3fbfbfabc9"
      ],
      "Text_cell_20" : [
        "9a828618-233d-48ee-9f0c-3f3fbfbfabc9"
      ],
      "Text_cell_25" : [
        "9a828618-233d-48ee-9f0c-3f3fbfbfabc9"
      ],
      "Text_cell_35" : [
        "9a828618-233d-48ee-9f0c-3f3fbfbfabc9"
      ],
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_149" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_101" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1",
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_7" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_18" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_22" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ]
    },
    "ff979c70-2dda-4728-9936-437816063a73" : {
      "Rectangle_4" : [
        "fa35afbc-3c59-4e9f-b320-94fc011e6274"
      ],
      "Rectangle_6" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_16" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_10" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_12" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_25" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_26" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_112" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ]
    },
    "7d21f3a6-99c9-4582-93e9-f6180cc48ea6" : {
      "Rectangle_1" : [
        "ff979c70-2dda-4728-9936-437816063a73"
      ],
      "Rectangle_4" : [
        "fa35afbc-3c59-4e9f-b320-94fc011e6274"
      ],
      "Text_16" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_10" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_12" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_25" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_26" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_112" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ]
    },
    "3e03e87e-61f7-48c1-8458-421172f60fe0" : {
      "Rectangle_3" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Rectangle_5" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e",
        "0c77625b-8c01-46e3-8617-7e590fae4bab"
      ]
    },
    "8f99e69f-6c97-4011-bb96-b1ab2f9382c2" : {
      "Image_18" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_41" : [
        "84d5e668-0f84-4a22-b975-0e5f243c1213"
      ],
      "Rectangle_92" : [
        "59a40226-fef3-4102-b072-c84d1387ab00"
      ],
      "Rectangle_91" : [
        "5ea20b8c-485b-4754-9b54-2ac90bf47820"
      ],
      "Image_150" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Image_102" : [
        "a179181f-3783-4f8e-bc39-745e9d8c4b39"
      ],
      "Image_103" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Image_104" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_10" : [
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ],
      "Text_12" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_25" : [
        "7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
      ],
      "Text_26" : [
        "f80f0a45-77df-4324-8c41-30b7e2f471b1"
      ],
      "Text_112" : [
        "1feafde6-a728-434d-b077-538c7c943721"
      ],
      "Text_16" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ],
      "Image_151" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e" : {
      "Image_15" : [
        "3e03e87e-61f7-48c1-8458-421172f60fe0"
      ],
      "Rectangle_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "0c77625b-8c01-46e3-8617-7e590fae4bab",
        "8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
      ]
    },
    "913aa6c3-68cf-43b3-8886-60d8ba94b7d9" : {
      "Rectangle_3" : [
        "0c77625b-8c01-46e3-8617-7e590fae4bab"
      ],
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ]
    },
    "0c77625b-8c01-46e3-8617-7e590fae4bab" : {
      "Rectangle_18" : [
        "913aa6c3-68cf-43b3-8886-60d8ba94b7d9"
      ],
      "Text_15" : [
        "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
      ]
    },
    "f39803f7-df02-4169-93eb-7547fb8c961a" : {
      "UNSW_logo" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "76f190ff-7245-440f-9acd-7d1bda7540c3" : {
      "UNSW_logo" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "72a00a31-4ee7-4cc0-a529-ffd44c8c0561" : {
    },
    "0bdd2598-0c1f-48b2-b857-a8602c4955f7" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);