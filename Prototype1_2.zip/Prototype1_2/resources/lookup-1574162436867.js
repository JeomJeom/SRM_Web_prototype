(function(window, undefined) {
  var dictionary = {
    "f80f0a45-77df-4324-8c41-30b7e2f471b1": "Enquiry_Dashboard",
    "1feafde6-a728-434d-b077-538c7c943721": "Edit_New_campaign",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "CS_dashboard",
    "0b1512e3-2f35-4c77-9c09-952f6458f352": "Enquiry_Unassigned",
    "45fe9b48-b49f-4fc6-833a-91d3a6bb3f56": "Enquiry_in-progress",
    "5ea20b8c-485b-4754-9b54-2ac90bf47820": "Edit_existing_campaign",
    "a179181f-3783-4f8e-bc39-745e9d8c4b39": "Compose_email",
    "fa35afbc-3c59-4e9f-b320-94fc011e6274": "Create_email_list",
    "59a40226-fef3-4102-b072-c84d1387ab00": "Create_New_campaign",
    "9a828618-233d-48ee-9f0c-3f3fbfbfabc9": "Enquiry_Detail",
    "84d5e668-0f84-4a22-b975-0e5f243c1213": "Enquiry_Resolved",
    "ff979c70-2dda-4728-9936-437816063a73": "Edit_email_list",
    "7d21f3a6-99c9-4582-93e9-f6180cc48ea6": "email_list",
    "3e03e87e-61f7-48c1-8458-421172f60fe0": "Start page",
    "8f99e69f-6c97-4011-bb96-b1ab2f9382c2": "Marketing_dashboard",
    "2a500ecb-ba85-4103-b7a4-5dd38e6bde1e": "Login page",
    "913aa6c3-68cf-43b3-8886-60d8ba94b7d9": "Submitted",
    "0c77625b-8c01-46e3-8617-7e590fae4bab": "Ticket Enquiry",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "CS_Content_template",
    "76f190ff-7245-440f-9acd-7d1bda7540c3": "Marketing_Content_template",
    "6650eb9b-403e-42fa-bdfc-4d148a99bef0": "CRM_Login_template",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "72a00a31-4ee7-4cc0-a529-ffd44c8c0561": "Student_Content_template",
    "0bdd2598-0c1f-48b2-b857-a8602c4955f7": "Navigation Bars",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);