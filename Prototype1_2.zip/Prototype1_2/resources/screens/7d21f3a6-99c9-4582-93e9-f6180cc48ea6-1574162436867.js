jQuery("#simulation")
  .on("click", ".s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/f80f0a45-77df-4324-8c41-30b7e2f471b1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_25")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_26")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/f80f0a45-77df-4324-8c41-30b7e2f471b1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_112")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/1feafde6-a728-434d-b077-538c7c943721"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mousedown", ".s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 .mousedown", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Rectangle_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/ff979c70-2dda-4728-9936-437816063a73"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/fa35afbc-3c59-4e9f-b320-94fc011e6274"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Triangle_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Triangle_3": {
                      "attributes": {
                        "background-color": "#AF924D"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Triangle_3": {
                      "attributes-ie": {
                        "-pie-background": "#AF924D",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-User_Dropdown" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_151")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_150")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_102")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/a179181f-3783-4f8e-bc39-745e9d8c4b39"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_103")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_104")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/1feafde6-a728-434d-b077-538c7c943721"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusin", ".s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 .focusin", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Input_1": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Input_1 input": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Input_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusout", ".s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 .focusout", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Input_1": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Input_1 input": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Input_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#C8C8C8",
                        "border-right-color": "#C8C8C8",
                        "border-bottom-color": "#C8C8C8",
                        "border-left-color": "#C8C8C8",
                        "box-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Cell_2") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_4") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_6") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_11") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Paragraph_11 span": {
                      "attributes": {
                        "text-decoration": "underline"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_8") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_10") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_2 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_8 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_10 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_6 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_4 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_17") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_18") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_19") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_17") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Paragraph_17 span": {
                      "attributes": {
                        "text-decoration": "underline"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_20") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_21") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_21 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_17 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_20 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_19 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_18 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_25") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_26") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_27") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_23") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Paragraph_23 span": {
                      "attributes": {
                        "text-decoration": "underline"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_28") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Cell_29") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_28 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_25 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_29 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_26 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 .verticalalign": {
                      "attributes": {
                        "vertical-align": "middle"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes": {
                        "background-color": "#F3F3F3"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27": {
                      "attributes-ie": {
                        "-pie-background": "#F3F3F3",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Cell_27 > .valign": {
                      "attributes-ie": {
                        "vertical-align": "middle"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_33") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_102") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_103") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_104") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_12") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Nav_left_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_25") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Nav_left_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Rectangle_12 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Rectangle_12": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Rectangle_14 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Rectangle_14": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Rectangle_16 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 #s-Rectangle_16": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-7d21f3a6-99c9-4582-93e9-f6180cc48ea6 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Cell_2")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_4")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_6")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_11")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_8")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_10")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_17")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_18")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_19")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_17")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_20")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_21")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_25")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_26")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_27")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Paragraph_23")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_28")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Cell_29")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_33")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Image_102")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Image_103")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Image_104")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_12")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_25")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_12")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_14")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_16")) {
      jEvent.undoCases(jFirer);
    }
  });