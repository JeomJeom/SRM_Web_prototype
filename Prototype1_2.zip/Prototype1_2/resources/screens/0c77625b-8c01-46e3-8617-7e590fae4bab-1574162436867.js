jQuery("#simulation")
  .on("click", ".s-0c77625b-8c01-46e3-8617-7e590fae4bab .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Basic_Button-Neutral_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Basic_Button-Neutral_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Basic_Button-Neutral_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Basic_Button-Neutral_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/913aa6c3-68cf-43b3-8886-60d8ba94b7d9"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_10",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_11",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_12",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_13",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_14",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_15",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_16",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_17",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_2",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_3",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_4",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_5",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_6",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_7",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_8",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_1" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Rectangle_9",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 500,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 400,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "90"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-arrow")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseup", ".s-0c77625b-8c01-46e3-8617-7e590fae4bab .mouseup", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Basic_Button-BrandAction_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#0070D2",
                        "background-attachment": "scroll",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6": {
                      "attributes-ie": {
                        "-pie-background": "#0070D2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mousedown", ".s-0c77625b-8c01-46e3-8617-7e590fae4bab .mousedown", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Basic_Button-Neutral_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#0070D2",
                        "background-attachment": "scroll",
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes-ie": {
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "-pie-background": "#0070D2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Basic_Button-Neutral_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#0070D2",
                        "background-attachment": "scroll",
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes-ie": {
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "-pie-background": "#0070D2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Basic_Button-Neutral_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#0070D2",
                        "background-attachment": "scroll",
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes-ie": {
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "-pie-background": "#0070D2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Basic_Button-Neutral_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#0070D2",
                        "background-attachment": "scroll",
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_10": {
                      "attributes-ie": {
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "-pie-background": "#0070D2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_9": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_7": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3 span": {
                      "attributes": {
                        "color": "#0070D2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-Neutral_3": {
                      "attributes-ie": {
                        "border-top-color": "#CCCCCC",
                        "border-right-color": "#CCCCCC",
                        "border-bottom-color": "#CCCCCC",
                        "border-left-color": "#CCCCCC",
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 400,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-arrow_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Options_1" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 400,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow_1" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-arrow")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Options" ],
                    "effect": {
                      "type": "slide",
                      "easing": "swing",
                      "duration": 400,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#s-arrow" ],
                    "angle": {
                      "type": "rotateby",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "swing",
                      "duration": 400
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Triangle_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Triangle_3": {
                      "attributes": {
                        "background-color": "#AF924D"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Triangle_3": {
                      "attributes-ie": {
                        "-pie-background": "#AF924D",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-User_Dropdown" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_13")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_13",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-ChatBot" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Image_13" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_73")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_13" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Incoming_call_docked_composer" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_75")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_13" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Incoming_call_docked_composer" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Basic_Button-BrandAction_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#005FB2",
                        "background-attachment": "scroll",
                        "box-shadow": "0px 0px 5px 0px #005FB2"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6": {
                      "attributes-ie": {
                        "-pie-background": "#005FB2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusin", ".s-0c77625b-8c01-46e3-8617-7e590fae4bab .focusin", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Input_4 textarea": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Input_4 > .backgroundLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-color": "#0070D2",
                        "border-right-width": "1px",
                        "border-right-color": "#0070D2",
                        "border-bottom-width": "1px",
                        "border-bottom-color": "#0070D2",
                        "border-left-width": "1px",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Error_2" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusout", ".s-0c77625b-8c01-46e3-8617-7e590fae4bab .focusout", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Input_4 textarea": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Input_4 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#D9D9D9",
                        "border-right-color": "#D9D9D9",
                        "border-bottom-color": "#D9D9D9",
                        "border-left-color": "#D9D9D9",
                        "box-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_4",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Input_4 > .backgroundLayer": {
                      "attributes": {
                        "border-top-width": "2px",
                        "border-top-color": "#B1433B",
                        "border-right-width": "2px",
                        "border-right-color": "#B1433B",
                        "border-bottom-width": "2px",
                        "border-bottom-color": "#B1433B",
                        "border-left-width": "2px",
                        "border-left-color": "#B1433B"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Error_2" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".s-0c77625b-8c01-46e3-8617-7e590fae4bab .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Basic_Button-BrandAction_6") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#005FB2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-0c77625b-8c01-46e3-8617-7e590fae4bab #s-Basic_Button-BrandAction_6": {
                      "attributes-ie": {
                        "-pie-background": "#005FB2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-0c77625b-8c01-46e3-8617-7e590fae4bab .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Basic_Button-BrandAction_6")) {
      jEvent.undoCases(jFirer);
    }
  });