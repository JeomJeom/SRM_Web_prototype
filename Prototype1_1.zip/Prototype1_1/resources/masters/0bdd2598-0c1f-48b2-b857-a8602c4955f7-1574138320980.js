jQuery("#simulation")
  .on("click", ".m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#m-0bdd2598-Rectangle_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-0bdd2598-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-0bdd2598-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-0bdd2598-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseup", ".m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 .mouseup", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#m-0bdd2598-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_17 > .backgroundLayer": {
                      "attributes": {
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_17": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mousedown", ".m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 .mousedown", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#m-0bdd2598-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_17 > .backgroundLayer": {
                      "attributes": {
                        "box-shadow": "0px 0px 3px 0px #005FB2"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_17": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Triangle_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Triangle_3": {
                      "attributes": {
                        "background-color": "#AF924D"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Triangle_3": {
                      "attributes-ie": {
                        "-pie-background": "#AF924D",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#m-0bdd2598-User_Dropdown" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Ellipse_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#m-0bdd2598-User_Dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusin", ".m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 .focusin", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#m-0bdd2598-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Input_1": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Input_1 input": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Input_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#m-0bdd2598-Search_bar_dropdown" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusout", ".m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 .focusout", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#m-0bdd2598-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Input_1": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Input_1 input": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Input_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#C8C8C8",
                        "border-right-color": "#C8C8C8",
                        "border-bottom-color": "#C8C8C8",
                        "border-left-color": "#C8C8C8",
                        "box-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#m-0bdd2598-Rectangle_11") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_11 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_11": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_13") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_13 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_13": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_15") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_15 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Rectangle_15": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_17") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 #m-0bdd2598-Image_13 > svg": {
                      "attributes": {
                        "overlay": "#005FB2"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Image_149") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#m-0bdd2598-Left_nav_expand" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-0bdd2598-Image_101") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#m-0bdd2598-Left_nav_expand" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".m-0bdd2598-0c1f-48b2-b857-a8602c4955f7 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#m-0bdd2598-Rectangle_11")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_13")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_15")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-0bdd2598-Rectangle_17")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-0bdd2598-Image_149")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-0bdd2598-Image_101")) {
      jEvent.undoCases(jFirer);
    }
  });