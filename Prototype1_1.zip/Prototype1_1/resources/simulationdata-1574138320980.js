function initData() {
  jimData.variables["John"] = "z1234567";
  jimData.variables["Amy"] = "z1345678";
  jimData.variables["Sam"] = "z5123456";
  jimData.isInitialized = true;
}