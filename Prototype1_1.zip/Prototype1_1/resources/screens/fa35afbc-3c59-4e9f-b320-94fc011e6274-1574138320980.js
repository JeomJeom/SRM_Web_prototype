jQuery("#simulation")
  .on("click", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_Dashboad_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/2a500ecb-ba85-4103-b7a4-5dd38e6bde1e"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/f80f0a45-77df-4324-8c41-30b7e2f471b1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_25")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_26")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/f80f0a45-77df-4324-8c41-30b7e2f471b1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_112")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/1feafde6-a728-434d-b077-538c7c943721"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_27")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_29")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseup", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .mouseup", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Rectangle_25")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_26")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#0070D2",
                        "background-attachment": "scroll",
                        "box-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26": {
                      "attributes-ie": {
                        "-pie-background": "#0070D2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mousedown", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .mousedown", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Rectangle_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/ff979c70-2dda-4728-9936-437816063a73"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_25")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EFEFEF",
                        "background-attachment": "scroll",
                        "box-shadow": "0px 0px 5px 0px #005FB2"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25": {
                      "attributes-ie": {
                        "-pie-background": "#EFEFEF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_26")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#005FB2",
                        "background-attachment": "scroll",
                        "box-shadow": "0px 0px 5px 0px #005FB2"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26": {
                      "attributes-ie": {
                        "-pie-background": "#005FB2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Triangle_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Triangle_3": {
                      "attributes": {
                        "background-color": "#AF924D"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Triangle_3": {
                      "attributes-ie": {
                        "-pie-background": "#AF924D",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-User_Dropdown" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_151")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_150")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/8f99e69f-6c97-4011-bb96-b1ab2f9382c2"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_102")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/a179181f-3783-4f8e-bc39-745e9d8c4b39"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_103")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7d21f3a6-99c9-4582-93e9-f6180cc48ea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_104")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/1feafde6-a728-434d-b077-538c7c943721"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("click", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .toggle", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Hotspot_1")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_16 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_16": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_16": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_3" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_2" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Hotspot_2")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_17 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_17": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_17": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_5" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_4" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Hotspot_3")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_18 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_18": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_18": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_7" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_6" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Hotspot_4")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_19 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_19": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_19": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_9" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_8" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Hotspot_5")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_20 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_20": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_20": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_11" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_10" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Hotspot_6")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_21 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_21": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_21": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_13" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_12" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Hotspot_7")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_22 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_22": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_22": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_15" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_14" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Hotspot_8")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimChangeStyle",
                    "parameter": [ {
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_23 > .backgroundLayer": {
                        "attributes": {
                          "background-color": "#74C787",
                          "background-attachment": "scroll",
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "box-shadow": "0px 0px 3px 0px #0070D2"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_23": {
                        "attributes": {
                          "text-shadow": "none"
                        }
                      }
                    },{
                      "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_23": {
                        "attributes-ie": {
                          "border-top-color": "#0070D2",
                          "border-right-color": "#0070D2",
                          "border-bottom-color": "#0070D2",
                          "border-left-color": "#0070D2",
                          "-pie-background": "#74C787",
                          "-pie-poll": "false"
                        }
                      }
                    } ],
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimShow",
                    "parameter": {
                      "target": [ "#s-Image_17" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  },
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": [ "#s-Image_16" ]
                    },
                    "exectype": "parallel",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    }
  })
  .on("focusin", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .focusin", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Input_1": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Input_1 input": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Input_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#0070D2",
                        "border-right-color": "#0070D2",
                        "border-bottom-color": "#0070D2",
                        "border-left-color": "#0070D2",
                        "box-shadow": "0px 0px 3px 0px #0070D2"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Search_bar_dropdown" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("focusout", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .focusout", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Input_1": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Input_1 input": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Input_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#C8C8C8",
                        "border-right-color": "#C8C8C8",
                        "border-bottom-color": "#C8C8C8",
                        "border-left-color": "#C8C8C8",
                        "box-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Hotspot_1")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_2",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_16 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_16": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_2")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_4",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_17 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_17": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_3")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_6",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_18 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_18": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_4")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_8",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_19 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_19": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_5")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_10",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_20 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_20": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_6")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_12",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_21 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_21": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_7")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_14",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_22 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_22": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_8")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_16",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_23 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_23": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Hotspot_1") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_1").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_1") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_2",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_16 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_16": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_2") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_2").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_2") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_4",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_17 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_17": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_3") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_3").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_3") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_6",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_18 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_18": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_4") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_4").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_4") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_8",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_19 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_19": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_5") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_5").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_5") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_10",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_20 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_20": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_6") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_6").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_6") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_12",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_21 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_21": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_7") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_7").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_7") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_14",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_22 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_22": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_8") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_8").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Hotspot_8") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "datatype": "property",
                "target": "#s-Image_16",
                "property": "jimIsVisible"
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_23 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "transparent",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_23": {
                      "attributes-ie": {
                        "-pie-background": "transparent",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_25") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EFEFEF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_25": {
                      "attributes-ie": {
                        "-pie-background": "#EFEFEF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_26") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#005FB2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_26": {
                      "attributes-ie": {
                        "-pie-background": "#005FB2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_33") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_102") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_103") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_104") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Left_nav_expand_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_12") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Nav_left_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_25") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Nav_left_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_12 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_12": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_27") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_27 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_27": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_29") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_29 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F2F2F2",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-fa35afbc-3c59-4e9f-b320-94fc011e6274 #s-Rectangle_29": {
                      "attributes-ie": {
                        "-pie-background": "#F2F2F2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-fa35afbc-3c59-4e9f-b320-94fc011e6274 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_25")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_26")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_33")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Image_102")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Image_103")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Image_104")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_12")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_25")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_12")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_27")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Rectangle_29")) {
      jEvent.undoCases(jFirer);
    }
  });